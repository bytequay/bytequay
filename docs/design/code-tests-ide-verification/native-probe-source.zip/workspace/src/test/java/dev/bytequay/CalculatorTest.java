package dev.bytequay;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
class CalculatorTest {
  @Test void twice() { assertEquals(7, new Calculator().twice(3)); }
}
