import { defineConfig } from 'vite';
import fs from 'node:fs';
const repo = '/Users/jack.chen/IdeaProjects/bytequay/frontend';
export default defineConfig({
  resolve: { alias: { '@xterm/addon-ligatures': '/tmp/bytequay-modular-ide-probe/node_modules/@xterm/addon-ligatures/lib/addon-ligatures.js', '@codingame/monaco-vscode-api/vscode/vs/base/browser/cssValue': '/tmp/bytequay-modular-ide-probe/node_modules/@codingame/monaco-vscode-api/vscode/src/vs/base/browser/cssValue.js', react: `${repo}/node_modules/react`, 'react-dom': `${repo}/node_modules/react-dom` }, dedupe: ['react', 'react-dom'] },
  optimizeDeps: {exclude: ['@codingame/monaco-vscode-theme-defaults-default-extension', '@codingame/monaco-vscode-javascript-default-extension', '@codingame/monaco-vscode-textmate-service-override']},
  build: {target: 'esnext', commonjsOptions: {exclude: [/@codingame/]}},
  worker: {format: 'es'},
  esbuild: { jsx: 'automatic' },
  server: { host: '127.0.0.1', port: 5198, strictPort: true, fs: { allow: ['/tmp/bytequay-modular-ide-probe', '/private/tmp/bytequay-modular-ide-probe', repo] } },
  plugins: [{name: 'probe-report', configureServer(server) {
    server.middlewares.use('/probe-report', (req, res) => {
      if (req.method !== 'POST') {res.statusCode = 405; res.end(); return;}
      let body=''; req.on('data', d=>body+=d); req.on('end', ()=>{fs.writeFileSync('/tmp/bytequay-modular-ide-probe/result.json', body); res.end('ok');});
    });
  }}]
});
