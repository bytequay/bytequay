package dev.bytequay;
public class Calculator {
  public int twice(int value) { return value * 2; }
  public int caller() { return twice(3); }
  public static void main(String[] args) {
    int result = new Calculator().caller();
    System.out.println(result);
  }
}
