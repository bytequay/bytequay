fn twice(value: i32) -> i32 {
 value * 2
}
fn caller() -> i32 { twice(3) }
fn main() { println!("{}", caller()); }
#[cfg(test)]
mod tests {
 use super::*;
 #[test]
 fn doubles() { assert_eq!(twice(3), 7); }
}
