import {defineConfig} from 'vite';
import {textmateImports} from '/Users/jack.chen/.codex/worktrees/modular-code-tests/bytequay/frontend/ideBuild.ts';
export default defineConfig({base:'./',resolve:{alias:{'@codingame/monaco-vscode-api/vscode/vs/base/browser/cssValue':'/Users/jack.chen/.codex/worktrees/modular-code-tests/bytequay/frontend/node_modules/@codingame/monaco-vscode-api/vscode/src/vs/base/browser/cssValue.js'}},plugins:[textmateImports()],build:{target:'esnext'},worker:{format:'es'}});
