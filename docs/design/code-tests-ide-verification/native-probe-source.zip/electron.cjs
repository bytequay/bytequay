const {app,BrowserWindow,WebContentsView,protocol,net,ipcMain}=require('electron');
const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {spawn}=require('node:child_process');
const {randomBytes}=require('node:crypto');
const root=__dirname;
const bundle='/Users/jack.chen/.codex/worktrees/modular-code-tests/bytequay/frontend/vendor/ide';
const authority='127.0.0.1:5203';
const connectionToken=randomBytes(32).toString('hex');
const manifest=JSON.parse(fs.readFileSync(path.join(bundle,'runtimeManifest.json'),'utf8'));
app.setPath('userData',path.join(root,'electron-profile'));
protocol.registerSchemesAsPrivileged([{scheme:'bytequay-ide',privileges:{standard:true,secure:true,supportFetchAPI:true,corsEnabled:true}}]);
let server;
let view;
let quitting=false;
app.on('before-quit',event=>{
  if(quitting)return;
  quitting=true;
  if(view&&!view.webContents.isDestroyed())view.webContents.close({waitForBeforeUnload:false});
  if(server?.pid){try{process.kill(-server.pid,'SIGTERM')}catch(error){if(error.code!=='ESRCH')console.error(error)}}
});
app.whenReady().then(async()=>{
  fs.writeFileSync(path.join(root,'token'),connectionToken,{mode:0o600});
  const extensions=path.join(root,'extensions');fs.mkdirSync(extensions,{recursive:true});
  for(const extension of manifest.extensions){const name=`${extension.id}-${extension.version}`;const link=path.join(extensions,name);if(!fs.existsSync(link))fs.symlinkSync(path.join(bundle,'extensions',name),link);}
  const log=fs.openSync(path.join(root,'server.log'),'a');
  server=spawn(path.join(bundle,'server/bin/codium-server'),['--host','127.0.0.1','--port','5203','--connection-token-file',path.join(root,'token'),'--server-data-dir',path.join(root,'server-data'),'--extensions-dir',extensions,'--telemetry-level','off','--log','info','--disable-workspace-trust','--reconnection-grace-time','0'],{detached:true,stdio:['ignore',log,log],env:{...process.env,PATH:'/tmp/bytequay-toolchains/rust/bin:/tmp/bytequay-toolchains/go/bin:/tmp/bytequay-toolchains/go-tools:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',CARGO_HOME:'/tmp/bytequay-toolchains/cargo-home',GOCACHE:'/tmp/bytequay-toolchains/go-cache',GOMODCACHE:'/tmp/bytequay-toolchains/go-modules',GOTELEMETRY:'off'}});
  fs.closeSync(log);
  fs.writeFileSync(path.join(root,'owned-process.json'),JSON.stringify({server:server.pid,electron:process.pid}));
  for(let attempts=0;attempts<100;attempts++){
    try{await fetch(`http://${authority}/version`);break}catch{await new Promise(resolve=>setTimeout(resolve,100))}
  }
  const dist=fs.realpathSync(path.join(root,'dist'));
  const resourceRoots=['extensions','server'].map(name=>fs.realpathSync(path.join(bundle,name)));
  const resourceHandler=async request=>{
    try{
      const url=new URL(request.url);
      const requested=decodeURIComponent(url.pathname);
      const file=fs.realpathSync(url.hostname==='app'?path.join(dist,requested):requested);
      const roots=url.hostname==='app'?[dist]:url.hostname==='ide-assets.bytequay.invalid'?resourceRoots:[];
      if(!roots.some(base=>file.startsWith(base+path.sep)))return new Response('Forbidden',{status:403});
      return net.fetch(pathToFileURL(file).href);
    }catch{return new Response('Not found',{status:404})}
  };
  const window=new BrowserWindow({width:1500,height:1050,title:'ByteQuay native IDE verification',show:true,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});
  view=new WebContentsView({webPreferences:{preload:path.join(root,'preload.cjs'),sandbox:true,contextIsolation:true,nodeIntegration:false,partition:'ide-native-verification'}});
  view.webContents.session.protocol.handle('bytequay-ide',resourceHandler);
  view.webContents.session.protocol.handle('https',resourceHandler);
  window.contentView.addChildView(view);
  const layout=()=>{const [width,height]=window.getContentSize();view.setBounds({x:0,y:0,width,height})};
  layout();window.on('resize',layout);window.on('closed',()=>app.quit());
  view.webContents.setWindowOpenHandler(()=>({action:'deny'}));
  view.webContents.on('will-navigate',(event,url)=>{if(!url.startsWith('bytequay-ide://app/'))event.preventDefault()});
  view.webContents.session.setPermissionRequestHandler((_contents,_permission,callback)=>callback(false));
  view.webContents.session.webRequest.onBeforeRequest((details,callback)=>{
    const url=new URL(details.url);
    callback({cancel:!['bytequay-ide:','blob:','data:'].includes(url.protocol)&&!(url.hostname==='ide-assets.bytequay.invalid'||url.hostname==='127.0.0.1'&&url.port==='5203')});
  });
  ipcMain.on('ide-probe:report',(event,report)=>{if(event.sender===view.webContents)fs.writeFileSync(path.join(root,'ui-results.json'),JSON.stringify(report,null,2))});
  ipcMain.handle('ide-probe:bootstrap',event=>{
    if(event.sender!==view.webContents||event.senderFrame!==view.webContents.mainFrame)throw new Error('Unknown IDE view');
    return {authority,connectionToken,commit:manifest.serverCommit,path:fs.realpathSync(path.join(root,'workspace'))};
  });
  view.webContents.on('console-message',event=>console.log(`[renderer:${event.level}] ${event.message}`));
  await view.webContents.loadURL('bytequay-ide://app/index.html');
});
