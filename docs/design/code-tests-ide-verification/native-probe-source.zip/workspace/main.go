package main
import "fmt"
func twice(value int) int {
 return value * 2
}
func caller() int { return twice(3) }
func main() { fmt.Println(caller()) }
