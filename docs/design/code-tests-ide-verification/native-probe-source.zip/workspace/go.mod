module bytequay.dev/idefixture

go 1.27
