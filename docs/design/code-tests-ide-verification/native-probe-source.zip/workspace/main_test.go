package main
import "testing"
func TestTwice(t *testing.T) {
 if got := twice(3); got != 7 { t.Fatalf("expected 7, got %d", got) }
}
